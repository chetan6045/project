
# Chat App Pro

## Steps
1. Install Node.js and MySQL
2. Import database.sql into MySQL
3. In server.js, set your MySQL password
4. Run:
   npm install
   node server.js
5. Open frontend/login.html in browser

## Features
- Register / Login
- Rooms (create/join)
- Real-time chat (Socket.IO)
- Chat history from DB
