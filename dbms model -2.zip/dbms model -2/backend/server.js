const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const mysql = require("mysql2");
const bcrypt = require("bcrypt");
const cors = require("cors");
const crypto = require("crypto");

// In-memory reset tokens: { token -> { userId, expires } }
const resetTokens = {};

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

// 🔑 CHANGE PASSWORD HERE
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Chetan@0451",
  database: "chat_app"
});

db.connect(err => {
  if (err) {
    console.error("DB Error:", err);
    process.exit(1);
  }
  console.log("✅ DB Connected");
});

// -------- AUTH --------
app.post("/register", async (req, res) => {
  const { username, email, password, security_question, security_answer } = req.body;
  if (!username || !email || !password) return res.status(400).send("Missing fields");
  if (!security_question || !security_answer) return res.status(400).send("Security question and answer are required");

  const hashed = await bcrypt.hash(password, 10);
  const answerHashed = await bcrypt.hash(security_answer.toLowerCase().trim(), 10);

  db.query(
    "INSERT INTO users (username, email, password, security_question, security_answer) VALUES (?, ?, ?, ?, ?)",
    [username, email, hashed, security_question, answerHashed],
    (err) => {
      if (err) return res.status(400).send(err.sqlMessage || "Error");
      res.send("Registered");
    }
  );
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;

  db.query("SELECT * FROM users WHERE email=?", [email], async (err, result) => {
    if (err) return res.status(500).send("Error");
    if (result.length === 0) return res.status(404).send("User not found");

    const user = result[0];
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).send("Wrong password");

    res.json({ id: user.id, username: user.username, email: user.email });
  });
});

// -------- FORGOT PASSWORD --------

// Step 1: Look up account and return the security question key
app.post("/forgot-password/lookup", (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).send("Email is required");

  db.query("SELECT id, security_question FROM users WHERE email=?", [email], (err, rows) => {
    if (err) return res.status(500).send("Server error");
    if (rows.length === 0) return res.status(404).send("No account found with that email");
    if (!rows[0].security_question) return res.status(400).send("This account has no security question set. Please contact support.");

    res.json({ question: rows[0].security_question });
  });
});

// Step 2: Verify answer, return a one-time token
app.post("/forgot-password/verify", async (req, res) => {
  const { email, answer } = req.body;
  if (!email || !answer) return res.status(400).send("Missing fields");

  db.query("SELECT id, security_answer FROM users WHERE email=?", [email], async (err, rows) => {
    if (err) return res.status(500).send("Server error");
    if (rows.length === 0) return res.status(404).send("Account not found");

    const user = rows[0];
    const match = await bcrypt.compare(answer.toLowerCase().trim(), user.security_answer);
    if (!match) return res.status(401).send("Incorrect answer. Please try again.");

    // Generate a short-lived token (15 minutes)
    const token = crypto.randomBytes(32).toString("hex");
    resetTokens[token] = { userId: user.id, expires: Date.now() + 15 * 60 * 1000 };

    res.json({ token });
  });
});

// Step 3: Reset password using the token
app.post("/forgot-password/reset", async (req, res) => {
  const { token, new_password } = req.body;
  if (!token || !new_password) return res.status(400).send("Missing fields");
  if (new_password.length < 6) return res.status(400).send("Password must be at least 6 characters");

  const entry = resetTokens[token];
  if (!entry) return res.status(400).send("Invalid or expired reset link. Please start over.");
  if (Date.now() > entry.expires) {
    delete resetTokens[token];
    return res.status(400).send("Reset link has expired (15 min limit). Please start over.");
  }

  const hashed = await bcrypt.hash(new_password, 10);
  db.query("UPDATE users SET password=? WHERE id=?", [hashed, entry.userId], (err) => {
    if (err) return res.status(500).send("Server error");
    delete resetTokens[token]; // invalidate after use
    res.send("Password reset successfully");
  });
});

// -------- ROOMS --------
app.get("/rooms", (req, res) => {
  db.query("SELECT * FROM rooms ORDER BY id ASC", (err, rows) => {
    if (err) return res.status(500).send("Error");
    res.json(rows);
  });
});

app.post("/rooms", (req, res) => {
  const { room_name } = req.body;
  if (!room_name) return res.status(400).send("room_name required");
  db.query("INSERT INTO rooms (room_name) VALUES (?)", [room_name], (err, r) => {
    if (err) return res.status(500).send("Error");
    res.json({ id: r.insertId, room_name });
  });
});

// -------- MESSAGES (history) --------
app.get("/messages/:roomId", (req, res) => {
  const { roomId } = req.params;
  db.query(
    `SELECT m.message, m.created_at, u.username 
     FROM messages m 
     JOIN users u ON m.user_id = u.id
     WHERE m.room_id = ?
     ORDER BY m.created_at ASC
     LIMIT 200`,
    [roomId],
    (err, rows) => {
      if (err) return res.status(500).send("Error");
      res.json(rows);
    }
  );
});

// -------- SOCKET --------
io.on("connection", (socket) => {
  socket.on("joinRoom", ({ userId, roomId, username }) => {
    // leave previous rooms
    Object.keys(socket.rooms).forEach(r => {
      if (r !== socket.id) socket.leave(r);
    });
    socket.join(String(roomId));
    socket.data = { userId, roomId, username };
  });

  socket.on("sendMessage", ({ userId, roomId, message, username }) => {
    if (!message || !message.trim()) return;

    const senderName = username || socket.data?.username || "User";

    db.query(
      "INSERT INTO messages (user_id, room_id, message) VALUES (?, ?, ?)",
      [userId, roomId, message.trim()],
      (err) => {
        if (err) return;
        // broadcast to others in room (sender adds their own bubble)
        socket.to(String(roomId)).emit("receiveMessage", {
          username: senderName,
          message: message.trim(),
          time: new Date().toLocaleTimeString(),
          roomId
        });
      }
    );
  });

  socket.on("disconnect", () => {
    // could emit presence update here
  });
});

const PORT = 3000;
server.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
